sudo ip link del vcan0
