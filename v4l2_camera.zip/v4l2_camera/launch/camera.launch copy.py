# HH_240729
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='v4l2_camera',  # Replace with actual package name
            executable='v4l2_camera_node',
            name='v4l2_camera_node',
            output='screen',
            parameters=[
                {'camera_device': '/dev/video1'},  # Adjust the camera device path
                # {'video_device': '/dev/video1'},  # Adjust the camera device path
                {'image_encoding': 'yuv422_yuy2'},  # Use yuv422_yuy2 encoding
                {'camera_info_url': 'file:///home/a/.ros/camera_info/canlab.yaml'},  # Adjust the path
                {'camera_frame_id': 'camera'},  # Adjust camera frame id 
                {'pixel_format': 'YUYV'},  # FOURCC code for YUYV format
                {'output_encoding': 'yuv422_yuy2'},  # Use yuv422_yuy2 encoding
                {'image_size': [1920, 1080]},  # Set to 1920x1080 resolution
                # Add other parameters as needed
            ],
        ),
    ])
